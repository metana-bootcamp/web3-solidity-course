# Ethereum Smart Contract Analysis & Solidity Audit using Slither - Blockchain Security

In this video, I will show how to audit and find vulnerability inside an Ethereum smart contract written in Solidity using Slither, one of the best EVM smart contract analysis tools.

- Author: Patrick Ventuzelo 
- Link: https://academy.fuzzinglabs.com/introduction-to-ethereum-security

## Slither

Static Analyzer for Solidity

Install:
``` sh
pip3 install slither-analyzer
```

Links:
- https://github.com/crytic/slither
- https://blog.trailofbits.com/2018/10/19/slither-a-solidity-static-analysis-framework/

## Testing Slither

Install an old version of the solidity compiler using solc-select
``` sh
pip3 install solc-select
solc-select install 0.4.25
solc-select use 0.4.25
```

Run slither in an example:
``` sh
slither slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol


Compilation warnings/errors on slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol:
slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol:32:13: Warning: Return value of low-level calls not used.
            address(target).call.value(1000)();
            ^--------------------------------^
slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol:50:9: Warning: Return value of low-level calls not used.
        address(target).call.value(2)();
        ^-----------------------------^
slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol:60:9: Warning: Return value of low-level calls not used.
        address(target).call();
        ^--------------------^
slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol:64:9: Warning: Return value of low-level calls not used.
        address(target).call.value(1)();
        ^-----------------------------^
slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol:8:5: Warning: No visibility specified. Defaulting to "public". 
    constructor(address addr) {
    ^ (Relevant source part starts here and spans across multiple lines).
slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol:53:19: Warning: Unused function parameter. Remove or comment out the variable name to silence this warning.
    function bad5(address target) public {
                  ^------------^


ReentrancyBenign.bad2(address) (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#29-38) sends eth to arbitrary user
  Dangerous calls:
  - address(target).call.value(1000)() (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#32)
ReentrancyBenign.bad4(address) (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#46-51) sends eth to arbitrary user
  Dangerous calls:
  - address(target).call.value(2)() (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#50)
ReentrancyBenign.ethSender(address) (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#63-65) sends eth to arbitrary user
  Dangerous calls:
  - address(target).call.value(1)() (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#64)
Reference: https://github.com/crytic/slither/wiki/Detector-Documentation#functions-that-send-ether-to-arbitrary-destinations

ReentrancyBenign.bad2(address) (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#29-38) ignores return value by address(target).call.value(1000)() (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#32)
ReentrancyBenign.bad4(address) (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#46-51) ignores return value by address(target).call.value(2)() (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#50)
ReentrancyBenign.externalCaller(address) (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#59-61) ignores return value by address(target).call() (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#60)
ReentrancyBenign.ethSender(address) (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#63-65) ignores return value by address(target).call.value(1)() (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#64)
Reference: https://github.com/crytic/slither/wiki/Detector-Documentation#unchecked-low-level-calls

ReentrancyBenign.constructor(address).addr (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#8) lacks a zero-check on :
    - success = addr.call() (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#9)
ReentrancyBenign.bad1(address).target (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#23) lacks a zero-check on :
    - success = target.call() (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#24)
ReentrancyBenign.bad2(address).target (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#29) lacks a zero-check on :
    - success = target.call() (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#30)
    - address(target).call.value(1000)() (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#32)
ReentrancyBenign.bad4(address).target (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#46) lacks a zero-check on :
    - address(target).call.value(2)() (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#50)
Reference: https://github.com/crytic/slither/wiki/Detector-Documentation#missing-zero-address-validation

Reentrancy in ReentrancyBenign.bad0() (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#16-21):
  External calls:
  - ! (msg.sender.call()) (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#17)
  State variables written after the call(s):
  - counter += 1 (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#20)
Reentrancy in ReentrancyBenign.bad1(address) (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#23-27):
  External calls:
  - success = target.call() (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#24)
  State variables written after the call(s):
  - counter += 1 (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#26)
Reentrancy in ReentrancyBenign.bad2(address) (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#29-38):
  External calls:
  - success = target.call() (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#30)
  - address(target).call.value(1000)() (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#32)
  External calls sending eth:
  - address(target).call.value(1000)() (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#32)
  State variables written after the call(s):
  - counter += 1 (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#33)
Reentrancy in ReentrancyBenign.bad3(address) (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#40-44):
  External calls:
  - externalCaller(target) (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#41)
    - address(target).call() (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#60)
  State variables written after the call(s):
  - varChanger() (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#42)
    - anotherVariableToChange ++ (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#68)
Reentrancy in ReentrancyBenign.bad4(address) (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#46-51):
  External calls:
  - externalCaller(target) (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#47)
    - address(target).call() (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#60)
  - ethSender(address(0)) (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#48)
    - address(target).call.value(1)() (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#64)
  External calls sending eth:
  - ethSender(address(0)) (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#48)
    - address(target).call.value(1)() (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#64)
  State variables written after the call(s):
  - varChanger() (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#49)
    - anotherVariableToChange ++ (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#68)
Reentrancy in ReentrancyBenign.bad5(address) (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#53-57):
  External calls:
  - ethSender(address(0)) (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#54)
    - address(target).call.value(1)() (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#64)
  State variables written after the call(s):
  - varChanger() (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#55)
    - anotherVariableToChange ++ (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#68)
Reference: https://github.com/crytic/slither/wiki/Detector-Documentation#reentrancy-vulnerabilities-2

Pragma version^0.4.0 (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#1) allows old versions
solc-0.4.25 is not recommended for deployment
Reference: https://github.com/crytic/slither/wiki/Detector-Documentation#incorrect-versions-of-solidity

Low level call in ReentrancyBenign.constructor(address) (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#8-14):
  - success = addr.call() (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#9)
Low level call in ReentrancyBenign.bad0() (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#16-21):
  - ! (msg.sender.call()) (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#17)
Low level call in ReentrancyBenign.bad1(address) (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#23-27):
  - success = target.call() (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#24)
Low level call in ReentrancyBenign.bad2(address) (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#29-38):
  - success = target.call() (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#30)
  - address(target).call.value(1000)() (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#32)
Low level call in ReentrancyBenign.bad4(address) (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#46-51):
  - address(target).call.value(2)() (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#50)
Low level call in ReentrancyBenign.externalCaller(address) (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#59-61):
  - address(target).call() (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#60)
Low level call in ReentrancyBenign.ethSender(address) (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#63-65):
  - address(target).call.value(1)() (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#64)
Reference: https://github.com/crytic/slither/wiki/Detector-Documentation#low-level-calls

bad0() should be declared external:
  - ReentrancyBenign.bad0() (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#16-21)
bad1(address) should be declared external:
  - ReentrancyBenign.bad1(address) (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#23-27)
bad2(address) should be declared external:
  - ReentrancyBenign.bad2(address) (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#29-38)
bad3(address) should be declared external:
  - ReentrancyBenign.bad3(address) (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#40-44)
bad4(address) should be declared external:
  - ReentrancyBenign.bad4(address) (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#46-51)
bad5(address) should be declared external:
  - ReentrancyBenign.bad5(address) (slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol#53-57)
Reference: https://github.com/crytic/slither/wiki/Detector-Documentation#public-function-that-could-be-declared-external
slither/tests/detectors/reentrancy-benign/0.4.25/reentrancy-benign.sol analyzed (1 contracts with 78 detectors), 32 result(s) found

```

## Example: Missing.sol

``` js
pragma solidity ^0.4.25;

contract Missing{
    address private owner = 0x41414141;

    modifier onlyowner {
        require(msg.sender==owner);
        _;
    }

    // The name of the constructor should be Missing
    // Anyone can call the IamMissing once the contract is deployed
    function IamMissing()
        public 
    {
        owner = msg.sender;
    }

    function withdraw() 
        public 
        onlyowner
    {
       owner.transfer(this.balance);
    }
}

```

link: https://github.com/crytic/not-so-smart-contracts/blob/master/wrong_constructor_name/incorrect_constructor.sol

## Fuzzing Missing.sol with Echidna 

``` sh
slither Missing.sol

Compilation warnings/errors on Missing.sol:
Missing.sol:23:23: Warning: Using contract member "balance" inherited from the address type is deprecated. Convert the contract to "address" type to access the member, for example use "address(contract).balance" instead.
       owner.transfer(this.balance);
                      ^----------^


Pragma version^0.4.25 (Missing.sol#1) allows old versions
solc-0.4.25 is not recommended for deployment
Reference: https://github.com/crytic/slither/wiki/Detector-Documentation#incorrect-versions-of-solidity

Function Missing.IamMissing() (Missing.sol#13-17) is not in mixedCase
Reference: https://github.com/crytic/slither/wiki/Detector-Documentation#conformance-to-solidity-naming-conventions

IamMissing() should be declared external:
  - Missing.IamMissing() (Missing.sol#13-17)
withdraw() should be declared external:
  - Missing.withdraw() (Missing.sol#19-24)
Reference: https://github.com/crytic/slither/wiki/Detector-Documentation#public-function-that-could-be-declared-external
Missing.sol analyzed (1 contracts with 78 detectors), 5 result(s) found
```

# Going deeper

Check my dedicated fuzzing trainings:

- Rust Security Audit and Fuzzing: https://academy.fuzzinglabs.com/rust-security-audit-and-fuzzing-training
- Go Security Audit and Fuzzing: https://academy.fuzzinglabs.com/go-security-audit-and-fuzzing
- C/C++ WhiteBox Fuzzing training: https://academy.fuzzinglabs.com/c-whitebox-fuzzing
- WebAssembly Reversing and Dynamic Analysis: https://academy.fuzzinglabs.com/wasm-security-reversing-dynamic-analysis

# Stay tuned

- Twitter: https://twitter.com/pat_ventuzelo
- Telegram: https://t.me/fuzzinglabs
- Youtube: https://www.youtube.com/channel/UCGD1Qt2jgnFRjrfAITGdNfQ

Check my other tutorials and courses here: https://academy.fuzzinglabs.com/
